# Python-games
That is a Memory puzzle game wrote in Python 
I used the Pygame framework
